# WANK Vehicle Scanner (Android)

A GTA-inspired, original dark/neon vehicle-scanner interface for Android.

## What works
- Uses the phone's rear camera.
- On-device ML Kit text recognition scans the camera preview for standard UK registration plate patterns (AA00AAA).
- Lets the user confirm/edit a detected registration.
- Can query the official UK DVLA Vehicle Enquiry API when the user supplies their own authorised API key.
- Displays make, colour, fuel, year, tax and MOT fields returned by DVLA.
- Explicitly marks alarm and immobiliser status as UNKNOWN.

## Important limitations
A camera cannot determine whether an arbitrary vehicle alarm is armed, nor whether an immobiliser is installed or active. The public DVLA Vehicle Enquiry API does not provide alarm/immobiliser status, vehicle owner identity, or a live security state. This app does not attempt to bypass vehicle security or interrogate vehicle electronics.

## Build and install
1. Install Android Studio (current stable) on a computer.
2. Open this folder as an existing Android Studio project.
3. Allow Gradle to sync and install the Android SDK Platform 35 if prompted.
4. Connect an Android phone with USB debugging enabled, or use an emulator with a camera.
5. Press Run.

The first launch asks for camera permission.

## DVLA API
The DVLA Vehicle Enquiry Service requires an API key issued to an authorised user. Apply through the UK government DVLA Vehicle Enquiry Service documentation. Paste your key into the app's API key field. Do not share your key. For a production release, put the API call behind a secure backend rather than embedding a private API key in the app.

## Project details
- Kotlin
- CameraX
- Google ML Kit Text Recognition
- Android min SDK 26
- No GTA assets, logos, or proprietary game code are included; the visual style is an original homage.
