package com.wankscanner.app

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : AppCompatActivity() {
    private val lime = Color.rgb(183, 243, 74)
    private val bg = Color.rgb(8, 13, 10)
    private val panel = Color.rgb(18, 27, 21)
    private val muted = Color.rgb(151, 167, 153)
    private lateinit var cameraExecutor: ExecutorService
    private lateinit var previewView: PreviewView
    private lateinit var plateView: TextView
    private lateinit var statusView: TextView
    private lateinit var detailsView: TextView
    private lateinit var registrationInput: EditText
    private lateinit var apiKeyInput: EditText
    private val busy = AtomicBoolean(false)
    private var lastPlate = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cameraExecutor = Executors.newSingleThreadExecutor()
        buildScreen()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 41)
        }
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(18, 18, 18, 14)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = TextView(this).apply {
            text = "WANK  /  VEHICLE INTEL"
            textSize = 20f
            setTextColor(lime)
            typeface = android.graphics.Typeface.create("sans-serif-black", android.graphics.Typeface.BOLD)
        }
        val online = TextView(this).apply {
            text = "  ● SYSTEM READY"
            textSize = 10f
            setTextColor(lime)
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(online)
        root.addView(header)
        root.addView(label("CAMERA / LIVE PLATE RECOGNITION"), LinearLayout.LayoutParams(-1, -2).apply { topMargin = 14 })

        previewView = PreviewView(this).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            setBackgroundColor(Color.BLACK)
        }
        root.addView(previewView, LinearLayout.LayoutParams(-1, 0, 1.05f).apply {
            topMargin = 8; bottomMargin = 8
        })

        plateView = TextView(this).apply {
            text = "NO REGISTRATION LOCKED"
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(lime)
            setPadding(10, 14, 10, 14)
            setBackgroundColor(panel)
            typeface = android.graphics.Typeface.MONOSPACE
        }
        root.addView(plateView, LinearLayout.LayoutParams(-1, -2))
        statusView = label("POINT CAMERA AT A UK NUMBER PLATE")
        root.addView(statusView)

        val scanButton = button("SCAN / LOOK UP VEHICLE")
        scanButton.setOnClickListener {
            val reg = lastPlate.ifBlank { registrationInput.text.toString() }
            if (reg.isBlank()) {
                statusView.text = "No plate detected. Enter a registration below."
            } else {
                registrationInput.setText(reg)
                lookupVehicle(reg)
            }
        }
        root.addView(scanButton, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8 })

        root.addView(label("MANUAL REGISTRATION"), LinearLayout.LayoutParams(-1, -2).apply { topMargin = 10 })
        registrationInput = EditText(this).apply {
            hint = "e.g. AB12 CDE"
            setHintTextColor(muted)
            setTextColor(Color.WHITE)
            textSize = 17f
            singleLine = true
            setPadding(14, 4, 14, 4)
            setBackgroundColor(panel)
        }
        root.addView(registrationInput, LinearLayout.LayoutParams(-1, 52))
        root.addView(label("DVLA API KEY (OPTIONAL)"), LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8 })
        apiKeyInput = EditText(this).apply {
            hint = "Add your authorised DVLA Vehicle Enquiry API key"
            setHintTextColor(muted)
            setTextColor(Color.WHITE)
            textSize = 12f
            singleLine = true
            setPadding(14, 4, 14, 4)
            setBackgroundColor(panel)
        }
        root.addView(apiKeyInput, LinearLayout.LayoutParams(-1, 48))

        detailsView = TextView(this).apply {
            text = "VEHICLE REPORT\nAwaiting scan…\n\nALARM: UNKNOWN\nIMMOBILISER: UNKNOWN\nSECURITY: NOT VERIFIED"
            textSize = 13f
            setTextColor(Color.WHITE)
            setPadding(14, 12, 14, 12)
            setBackgroundColor(panel)
        }
        root.addView(detailsView, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 10 })
        val foot = TextView(this).apply {
            text = "FICTIONAL-STYLE INTERFACE  •  SECURITY STATUS REQUIRES AUTHORISED DATA"
            textSize = 9f
            gravity = Gravity.CENTER
            setTextColor(muted)
            setPadding(4, 10, 4, 2)
        }
        root.addView(foot)
        setContentView(root)
    }

    private fun label(value: String) = TextView(this).apply {
        text = value
        textSize = 10f
        letterSpacing = 0.12f
        setTextColor(muted)
        setPadding(2, 8, 2, 5)
    }

    private fun button(value: String) = Button(this).apply {
        text = value
        textSize = 13f
        setTextColor(bg)
        setBackgroundColor(lime)
        isAllCaps = false
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(previewView.surfaceProvider)
            }
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            analysis.setAnalyzer(cameraExecutor) { proxy ->
                if (!busy.compareAndSet(false, true)) {
                    proxy.close()
                    return@setAnalyzer
                }
                val media = proxy.image
                if (media == null) {
                    busy.set(false); proxy.close()
                    return@setAnalyzer
                }
                val image = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
                recognizer.process(image)
                    .addOnSuccessListener { result ->
                        val found = result.textBlocks.asSequence()
                            .flatMap { it.lines.asSequence() }
                            .map { it.text.uppercase().replace(" ", "").replace("-", "") }
                            .firstOrNull { Regex("^[A-Z]{2}[0-9]{2}[A-Z]{3}$").matches(it) }
                        if (!found.isNullOrBlank() && found != lastPlate) {
                            lastPlate = found
                            runOnUiThread {
                                plateView.text = "PLATE LOCKED  /  $found"
                                statusView.text = "REGISTRATION DETECTED — PRESS SCAN TO LOOK UP"
                            }
                        }
                    }
                    .addOnCompleteListener {
                        proxy.close()
                        busy.set(false)
                    }
            }
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
            } catch (e: Exception) {
                statusView.text = "Camera unavailable: ${e.localizedMessage}"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun lookupVehicle(raw: String) {
        val reg = raw.uppercase().replace(" ", "").trim()
        if (!Regex("^[A-Z]{2}[0-9]{2}[A-Z]{3}$").matches(reg)) {
            statusView.text = "Check the UK registration format and try again."
            return
        }
        val key = apiKeyInput.text.toString().trim()
        if (key.isEmpty()) {
            detailsView.text = "VEHICLE REPORT\nREGISTRATION: $reg\n\nALARM: UNKNOWN\nIMMOBILISER: UNKNOWN\nSECURITY: NOT VERIFIED\n\nAdd an authorised DVLA Vehicle Enquiry API key to retrieve available vehicle details. Alarm and immobiliser data are not supplied by the public DVLA service."
            statusView.text = "PLATE READ SUCCESSFULLY"
            return
        }
        statusView.text = "QUERYING DVLA VEHICLE ENQUIRY…"
        detailsView.text = "VEHICLE REPORT\nREGISTRATION: $reg\n\nRetrieving authorised vehicle data…"
        Thread {
            try {
                val connection = (URL("https://driver-vehicle-licensing.api.gov.uk/vehicle-enquiry/v1/vehicles").openConnection() as HttpURLConnection)
                connection.requestMethod = "POST"
                connection.connectTimeout = 12000
                connection.readTimeout = 12000
                connection.doOutput = true
                connection.setRequestProperty("Content-Type", "application/json")
                connection.setRequestProperty("x-api-key", key)
                connection.outputStream.use { it.write(JSONObject().put("registrationNumber", reg).toString().toByteArray()) }
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val body = stream.bufferedReader().use { it.readText() }
                if (code !in 200..299) throw Exception("DVLA response $code: $body")
                val data = JSONObject(body)
                val report = buildString {
                    append("VEHICLE REPORT\n")
                    append("REGISTRATION: $reg\n")
                    append("MAKE: ${data.optString("make", "Unknown")}\n")
                    append("COLOUR: ${data.optString("colour", "Unknown")}\n")
                    append("FUEL: ${data.optString("fuelType", "Unknown")}\n")
                    append("YEAR: ${data.optString("yearOfManufacture", "Unknown")}\n")
                    append("TAX STATUS: ${data.optString("taxStatus", "Unknown")}\n")
                    append("MOT STATUS: ${data.optString("motStatus", "Unknown")}\n")
                    append("MOT EXPIRY: ${data.optString("motExpiryDate", "Unknown")}\n\n")
                    append("ALARM: UNKNOWN\nIMMOBILISER: UNKNOWN\nSECURITY: NOT VERIFIED\n")
                    append("\nDVLA does not provide alarm or immobiliser status.")
                }
                runOnUiThread {
                    detailsView.text = report
                    statusView.text = "DVLA LOOKUP COMPLETE"
                }
                connection.disconnect()
            } catch (e: Exception) {
                runOnUiThread {
                    detailsView.text = "VEHICLE REPORT\nREGISTRATION: $reg\n\nALARM: UNKNOWN\nIMMOBILISER: UNKNOWN\n\nDVLA LOOKUP FAILED\n${e.localizedMessage ?: "Check API key and connection."}"
                    statusView.text = "LOOKUP FAILED — CHECK API KEY / NETWORK"
                }
            }
        }.start()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 41 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startCamera()
        else statusView.text = "Camera permission is required for plate scanning."
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::cameraExecutor.isInitialized) cameraExecutor.shutdown()
    }
}
